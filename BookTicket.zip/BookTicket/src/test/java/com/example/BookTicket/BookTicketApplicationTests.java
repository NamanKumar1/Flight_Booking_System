package com.example.BookTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
